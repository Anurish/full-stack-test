<?php
return [
    'app_name' => 'WPoets Full Stack Test',
    'base_url' => '',
    'db' => [
        'host' => '127.0.0.1',
        'name' => 'wpoets_full_stack_test',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4',
    ],
];
